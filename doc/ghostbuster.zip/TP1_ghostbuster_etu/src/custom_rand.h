//---------------------------------------------------------------------------

#ifndef custom_randH
#define custom_randH
//---------------------------------------------------------------------------

#include <stdint.h>

uint32_t rnd_32(void);
void init_rnd32(uint32_t seed);


#endif
